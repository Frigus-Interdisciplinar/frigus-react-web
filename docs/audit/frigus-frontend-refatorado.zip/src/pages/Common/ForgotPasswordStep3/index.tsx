import { useReducer, type FormEvent } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { CheckCircle2, ShieldAlert } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import Input from "@/components/Input";
import Button from "@/components/Button";
import ThemeToggle from "@/components/ThemeToggle";
import { resetPassword } from "@/services/auth.service";

type State = { password: string; confirmPassword: string; loading: boolean; success: boolean; error: string };
type Action =
  | { type: "passwordChanged"; value: string }
  | { type: "confirmationChanged"; value: string }
  | { type: "loading" }
  | { type: "failed"; message: string }
  | { type: "succeeded" };

const initialState: State = { password: "", confirmPassword: "", loading: false, success: false, error: "" };

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "passwordChanged": return { ...state, password: action.value, error: "" };
    case "confirmationChanged": return { ...state, confirmPassword: action.value, error: "" };
    case "loading": return { ...state, loading: true, error: "" };
    case "failed": return { ...state, loading: false, error: action.message };
    case "succeeded": return { ...state, loading: false, success: true, error: "" };
  }
}

export default function ForgotPasswordStep3() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { password, confirmPassword, loading, success, error } = state;
  const navigate = useNavigate();
  const location = useLocation();
  const recovery = location.state as { email?: string; code?: string } | null;

  if (!recovery?.email || !recovery.code) return <Navigate to="/forgot-password" replace />;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (password.length < 8 || password.length > 20 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/\d/.test(password) || !/[^A-Za-z0-9]/.test(password)) {
      dispatch({ type: "failed", message: "A senha deve conter de 8 a 20 caracteres, com letra maiúscula, minúscula, número e caractere especial." });
      return;
    }
    if (password !== confirmPassword) {
      dispatch({ type: "failed", message: "As senhas informadas não coincidem." });
      return;
    }

    dispatch({ type: "loading" });
    try {
      await resetPassword({ email: recovery!.email!, code: recovery!.code!, newPassword: password });
      dispatch({ type: "succeeded" });
    } catch (err) {
      dispatch({ type: "failed", message: err instanceof Error ? err.message : "Não foi possível redefinir a senha." });
    }
  };

  return (
    <AuthLayout
      title={"Defina uma senha\nnova e segura"}
      description="Escolha uma senha para voltar a usar o Frigus com total segurança e controle."
      cardTitle="Sua conta protegida"
      cardDescription="Use uma senha forte e que você ainda não utilize em outros serviços para proteger seus dados."
    >
      <div className="absolute top-6 right-6 z-20">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-[576px] bg-white dark:bg-[#1B1D20] rounded-2xl shadow-[0_16px_34px_0_rgba(19,28,85,0.08)] dark:shadow-[0_16px_34px_0_rgba(0,0,0,0.4)] border border-[#C9DEF9] dark:border-[#34383E] p-7 sm:p-12 flex flex-col gap-6">
        {success ? (
          <div className="flex flex-col items-center text-center py-4 gap-4">
            <CheckCircle2 className="size-16 text-emerald-500" />
            <h3 className="text-2xl font-bold text-frigus-navy dark:text-white">
              Senha redefinida com sucesso!
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Sua senha foi atualizada. Agora você já pode acessar sua conta normalmente.
            </p>
            <Button
              type="button"
              onClick={() => navigate("/login")}
              className="w-full h-12 text-base font-bold mt-3 shadow-md"
            >
              Ir para o Login
            </Button>
          </div>
        ) : (
          <>
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-frigus-navy dark:text-white leading-tight font-display">
                Criar nova senha
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1.5">
                Digite e confirme sua nova senha para continuar.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="flex flex-col gap-5">
              <Input
                id="new-password"
                label="Nova senha"
                type="password"
                placeholder="Digite sua nova senha"
                value={password}
                onChange={(e) => dispatch({ type: "passwordChanged", value: e.target.value })}
                required
                helperText="Use de 8 a 20 caracteres, com maiúscula, minúscula, número e símbolo."
              />

              <Input
                id="confirm-password"
                label="Confirmar senha"
                type="password"
                placeholder="Digite a senha novamente"
                value={confirmPassword}
                onChange={(e) => dispatch({ type: "confirmationChanged", value: e.target.value })}
                required
              />

              {error && (
                <div className="flex items-center gap-2 text-xs text-red-500 bg-red-50 dark:bg-red-950/30 p-2.5 rounded-lg border border-red-200 dark:border-red-900/40">
                  <ShieldAlert className="size-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <Button
                type="submit"
                disabled={loading || !password || !confirmPassword}
                className="w-full h-12 text-base font-bold shadow-md shadow-frigus-primary/20"
              >
                {loading ? "Salvando..." : "Salvar nova senha"}
              </Button>

              <div className="text-center pt-2">
                <Link
                  to="/login"
                  className="text-sm font-semibold text-frigus-primary dark:text-[#A7BCFF] hover:underline"
                >
                  Cancelar e voltar
                </Link>
              </div>
            </form>
          </>
        )}
      </div>
    </AuthLayout>
  );
}
