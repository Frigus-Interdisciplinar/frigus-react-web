import { Link } from "react-router-dom";
import {
  LayoutDashboard,
  Package,
  Utensils,
  ShoppingBasket,
  UsersRound,
  MessageCircle,
  Sparkles,
  Settings,
} from "lucide-react";
import NavigationItem from "./NavigationItem";
import frigusLogo from "@/assets/frigus-logo.svg";

import { type ReactNode } from "react";
import { useStore } from "@/store/store";

export type SectionString =
  | "home"
  | "stock"
  | "recipe"
  | "shopping-list"
  | "family-members"
  | "chat"
  | "chat-ai"
  | "settings"
  | "alerts"
  | "profile"
  | "plans"
  | "notifications"
  | undefined;

export type NavItem = {
  label: string;
  href: string;
  icon: ReactNode;
  section: SectionString;
};

const navigationItems: NavItem[] = [
  {
    label: "Visão geral",
    href: "/home",
    icon: <LayoutDashboard size={18} />,
    section: "home",
  },
  {
    label: "Meu estoque",
    href: "/stock",
    icon: <Package size={18} />,
    section: "stock",
  },
  {
    label: "Receitas",
    href: "/recipe",
    icon: <Utensils size={18} />,
    section: "recipe",
  },
  {
    label: "Compras",
    href: "/shopping-list",
    icon: <ShoppingBasket size={18} />,
    section: "shopping-list",
  },
  {
    label: "Família",
    href: "/family-members",
    icon: <UsersRound size={18} />,
    section: "family-members",
  },
  {
    label: "Chat",
    href: "/chat",
    icon: <MessageCircle size={18} />,
    section: "chat",
  },
  {
    label: "Chat IA",
    href: "/chat-ai",
    icon: <Sparkles size={18} />,
    section: "chat-ai",
  },
  {
    label: "Configurações",
    href: "/settings",
    icon: <Settings size={18} />,
    section: "settings",
  },
];

export type SidebarProps = {
  activeSection?: SectionString;
};

export default function Sidebar({ activeSection }: SidebarProps) {
  const user = useStore((state) => state.user);
  const initials = user?.name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase() ?? "—";
  return (
    <aside className="h-screen sticky top-0 bg-sidebar-bg dark:bg-[#171819] border-r border-transparent dark:border-white/5 w-[232px] p-3 flex flex-col justify-between shrink-0 select-none z-20 transition-colors">
      <div className="flex flex-col gap-6">
        <Link
          to="/home"
          className="flex items-center gap-2.5 px-1 pt-2 hover:opacity-90 transition-opacity"
        >
          <img
            src={frigusLogo}
            alt="Frigus Logo"
            className="w-8 h-8 object-contain"
          />
          <span className="font-display text-white text-lg tracking-wider font-semibold">
            Frigus
          </span>
        </Link>

        <nav className="flex flex-col gap-1">
          {navigationItems.map((item) => (
            <NavigationItem
              key={item.href}
              item={item}
              active={activeSection === item.section}
            />
          ))}
        </nav>
      </div>

      <Link
        to="/profile"
        className="pt-4 border-t border-white/10 flex items-center gap-3 px-2 hover:bg-white/5 rounded-lg transition-colors py-2"
      >
        <div className="w-9 h-9 rounded-full bg-frigus-ice flex items-center justify-center text-frigus-navy font-bold text-xs shrink-0">
          {initials}
        </div>
        <div className="flex flex-col overflow-hidden">
          <span className="text-white text-xs font-bold truncate">
            {user?.name ?? "Minha conta"}
          </span>
          <span className="text-sidebar-muted text-[11px] truncate">
            {user?.accountType === "DOMESTIC" ? "Plano doméstico" : "Plano Frigus"}
          </span>
        </div>
      </Link>
    </aside>
  );
}
